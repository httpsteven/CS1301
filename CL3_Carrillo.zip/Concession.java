public class Concession{
  private double popcornPrice;
  private double sodaPrice;
  private double hotdogPrice;
  private float tax;

  //CONSTRUCTORS(WITHOUT VALUES)
  public Concession(){

  }
  //CONSTRUCTORS(WITH VALUES)
  public Concession(double popcornPrice,double sodaPrice,double hotdogPrice, float tax){
    this.popcornPrice = popcornPrice;
    this.sodaPrice = sodaPrice;
    this.hotdogPrice = hotdogPrice;
    this.tax = tax;
  }
  //SETTERS
  public void setPopcornPrice(double popcornPrice){
    this.popcornPrice = popcornPrice;
  }
  public void setSodaPrice(double sodaPrice){
    this.sodaPrice = sodaPrice;
  }
  public void setHotdogPrice(double hotdogPrice){
    this.hotdogPrice = hotdogPrice;
  }
  public void setTax(float tax){
    this.tax = tax;
  }
  //GETTERS
  public double getPopcornPrice(){
    return popcornPrice;
  }
  public double getSodaPrice(){
    return sodaPrice;
  }
  public double getHotdogPrice(){
    return hotdogPrice;
  }
  public float getTax(){
    return tax;
  }
  //setTaxToPrice
  public void setTaxtoPrice(){
    setPopcornPrice(tax*popcornPrice);
    setSodaPrice(tax*sodaPrice);
    setHotdogPrice(tax*hotdogPrice);
  }
  public String toString(){
    return "POPCORN PRICE: " + popcornPrice +
           "SODA PRICE: " + sodaPrice +
           "HOTDOG PRICE: " + hotdogPrice;
  }
}
