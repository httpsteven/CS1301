import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class fileReader{
  private String fileName;
  //CONSTRUCTORS(WITHOUT VARIABLES)
  public fileReader(){
  }
  //CONSTRUCTORS(WITH VARIABLES)
  public fileReader(String fileName){
    this.fileName = fileName;
  }
  //SETTERS
  public void setfileName(String fileName){
    this.fileName = fileName;
  }
  //GETTERS
  public String getfileName(){
    return fileName;
  }
  //readFile
  public Event[] readFile()throws IOException{
    Event[] currEvent = new Event[getNumOfEvents()];
    Concession[] currConcession = new Concession[getNumOfEvents()];
    String [] token;
    String currLine;
    Scanner fileReader = new Scanner(new File(fileName));
    int i = 0;
    fileReader.nextLine();
    while(fileReader.hasNext()){
      currLine = fileReader.nextLine();
      token = currLine.split(",");
      currConcession[i] = new Concession(6.00, 1.50, 4.00, Float.parseFloat(token[5]));
      currConcession[i].setTaxtoPrice();
      currEvent[i] = new Event(token[0],
                               token[1],
                               token[2],
                               Float.parseFloat(token[3]),
                               Integer.parseInt(token[4]),
                               currConcession[i]);
      i++;
      }
      return currEvent;
    }
    public int getNumOfEvents()throws IOException{
      Scanner fileReader = new Scanner(new File(fileName));
      int numOfLines = -1;
      String currLine;
      while(fileReader.hasNext()){
        currLine = fileReader.nextLine();
        numOfLines++;
      }
      return numOfLines;
    }

}
