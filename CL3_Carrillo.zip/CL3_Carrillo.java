import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class CL3_Carrillo{
  //main
public static void main(String[] args)throws IOException{
  //initializing variables
  fileReader file = new fileReader("events-info.csv");
  Scanner userInput = new Scanner(System.in);
  Scanner banner = new Scanner(new File("welcome.txt"));
  long ccNumber;
  String ccString;
  String ccLastFour;
  int num = file.getNumOfEvents();
  Event[] events = new Event[num];
  events = file.readFile();
  boolean stayIn = true;
  boolean optionOne = true;
  boolean optionTwo = true;
  boolean optionThree = true;
  boolean optionFour = true;
  int choice = 0;
  int choiceTwo = 0;
  String choiceYN = "";
  String choiceConcession = "";
  double ticketTotal = 0f;
  double concessionTotal = 0f;
  double total = 0f;
  //banner
  while(banner.hasNextLine()){
    SOPln(banner.nextLine());
  }
  //Menu System
  do{
    SOPln("");
    SOPln("-----------------------------------------\n" +
          "1. - View Events -\n" +
          "2. - View Concessions -\n" +
          "3. - Purchase Tickets and Concessions -\n" +
          "4. - Exit System - \n" +
          "-----------------------------------------");
    SOPln("");
          choice = userInput.nextInt();
          //Choice 1 - View All Events
          if(choice == 1){
            viewAllEventNames(events);
          }
          //Choice 2 - View All Concessions
          if(choice == 2){
            viewAllConcessions(events);
          }
          //Choice 3 - Purchase Tickets and Concessions
          if(choice == 3){
            viewAllEventNames(events);
            do{
              //EVENT CHOICE
              SOPln("Enter the number of the event you'd like to attend:");
              choice = userInput.nextInt();
              if(choice > num || choice < 0){
                SOPln("Try again!");
              }if(choice <= num){
                choice--;
              SOPln("You selected " + events[choice].getEventName());
              SOPln("Tickets for " + events[choice].getEventName() +" cost $" + events[choice].getTicketPrice());
              do{
                //TICKET AMOUNT
                SOPln("How many tickets would you like to buy?");
                choiceTwo = userInput.nextInt();
                if(choiceTwo > events[choice].getAvailableTickets() || choiceTwo < 0){
                  SOPln("Try Again!");
                }
                if (choiceTwo <= events[choice].getAvailableTickets()){
                  SOPln("Your purchase was successful!");
                  ticketTotal = choiceTwo * events[choice].getTicketPrice();
                  System.out.printf("You will be charged $%.2f\n", ticketTotal);
                  SOPln("There are " + events[choice].purchaseTicket(choiceTwo) + " tickets left.");
                  SOPln("Would you like to buy concessions? (y/n)");
                  SOPln("");
                  choiceYN = userInput.next();
                  do{
                    //CONCESSIONS YES OR NO
                      if(choiceYN.toUpperCase().equals("Y")){
                      choiceYN = "";
                      SOPln("-----------------------------------------");
                      System.out.printf("Popcorn: $%.2f\n", events[choice].getConcessionStand().getPopcornPrice());
                      System.out.printf("Soda: $%.2f\n",  events[choice].getConcessionStand().getSodaPrice());
                      System.out.printf("Hotdog: $%.2f\n", events[choice].getConcessionStand().getHotdogPrice());
                      SOPln("-----------------------------------------");
                      SOPln("Which concession would you like to purchase? [enter name of the concession]");
                      do{
                        //CONCESSION CHOICE WITH NAMES
                        choiceConcession = userInput.next();
                        if(choiceConcession.toUpperCase().equals("POPCORN")){
                          SOPln("How many popcorns would you like to purchase?");
                          choiceTwo = userInput.nextInt();
                          concessionTotal = choiceTwo * events[choice].getConcessionStand().getPopcornPrice();
                          SOPln("Would you like to buy any more concessions? (y/n)");
                          choiceYN = userInput.next();
                          if(choiceYN.toUpperCase().equals("Y")){
                            optionFour = true;
                          }else if(choiceYN.toUpperCase().equals("N")){optionFour = false;}
                        }
                        if(choiceConcession.toUpperCase().equals("SODA")){
                          SOPln("How many sodas would you like to purchase?");
                          choiceTwo = userInput.nextInt();
                          concessionTotal = choiceTwo * events[choice].getConcessionStand().getSodaPrice();
                          SOPln("Would you like to buy any more concessions? (y/n)");
                          choiceYN = userInput.next();
                          if(choiceYN.toUpperCase().equals("Y")){
                            optionFour = true;
                          }else if(choiceYN.toUpperCase().equals("N")){optionFour = false;}
                        }
                        if(choiceConcession.toUpperCase().equals("HOTDOG")){
                          SOPln("How many hotdogs would you like to purchase?");
                          choiceTwo = userInput.nextInt();
                          concessionTotal = choiceTwo * events[choice].getConcessionStand().getHotdogPrice();
                          SOPln("Would you like to buy any more concessions? (y/n)");
                          choiceYN = userInput.next();
                          if(choiceYN.toUpperCase().equals("Y")){
                            optionFour = true;
                          }else if(choiceYN.toUpperCase().equals("N")){optionFour = false;}
                        }
                        if(!choiceConcession.toUpperCase().equals("POPCORN") &&
                           !choiceConcession.toUpperCase().equals("SODA") &&
                           !choiceConcession.toUpperCase().equals("HOTDOG")){
                             SOPln("Try Again.");
                           }
                           //FULL CHECKOUT PROCESS
                            if(optionFour = false){
                            SOPln("");
                           System.out.printf("Ticket Charge:  $%.2f\n", ticketTotal);
                           System.out.printf("Concession charge: $%.2f\n", concessionTotal);
                           System.out.printf("Total: $%.2f\n", (ticketTotal + concessionTotal));
                           do{
                             SOPln("Please enter a 16 digit credit card number to complete the purchase:");
                             SOP(">> ");
                              ccNumber = userInput.nextLong();
                              if(isCCNumberValid(ccNumber)){
                                optionFour = false;
                              }else optionFour = true;

                            }while(optionFour);
                         ccString = Long.toString(ccNumber);
                         if (ccString.length() != 16){
                           SOPln("Try Again.");
                         }
                         if (ccString.length() == 16){
                         ccLastFour = ccString.substring(ccString.length() - 4);
                         SOPln("You card ending in " + ccLastFour + " was charged $" + (ticketTotal + concessionTotal));
                         SOPln("Thank you for your purchase and for using PayDirtTickets!\n" + "Goodbye!");
                         optionThree = false;
                         optionTwo = false;
                         optionOne = false;
                         stayIn = false;}
                         }
                       }while(optionFour);
                        }
                    if(choiceYN.toUpperCase().equals("N")){
                      optionThree = false;
                      System.out.printf("Ticket Charge:  $%.2f\n", ticketTotal);
                      System.out.printf("Concession charge: $%.2f\n", concessionTotal);
                      System.out.printf("Total: $%.2f\n", (ticketTotal + concessionTotal));
                      do{
                        SOPln("Please enter a 16 digit credit card number to complete the purchase:");
                        SOP(">> ");
                         ccNumber = userInput.nextLong();
                         if(isCCNumberValid(ccNumber)){
                           optionFour = false;
                         }else optionFour = true;

                    ccString = Long.toString(ccNumber);
                    if (ccString.length() != 16){
                      SOPln("Try Again.");
                    }
                    if (ccString.length() == 16){
                    ccLastFour = ccString.substring(ccString.length() - 4);
                    SOPln("You card ending in " + ccLastFour + " was charged $" + (ticketTotal + concessionTotal));
                    SOPln("Thank you for your purchase and for using PayDirtTickets!\n" + "Goodbye!");
                    optionThree = false;
                    optionTwo = false;
                    optionOne = false;
                    stayIn = false;
                    }
                  }while(optionFour);
                    }

                  }while(optionThree);
                }


              }while(optionTwo);
              }

              }while(optionOne);
            }
        if(choice == 4){
          System.out.println("Thank you for using Pay Dirt Tickets");
          System.out.println("Goodbye.");
          stayIn = false;
        }
    }while(stayIn);
  }

  //isCreditCardValid Method
  public static boolean isCCNumberValid(long ccNumber){
    int length = String.valueOf(ccNumber).length();
    if(length == 16){
    return true;
      }else{
      return false;
      }
  }
//viewAllEventNames Method
  public static void viewAllEventNames(Event[] events){
    int event = 1;
    int counter = 0;
    while(event <= events.length){
      SOPln("All Events:\n");
      SOPln("-----------------" + "Event " + event + "-----------------");
      SOPln("Event Name: " + events[counter].getEventName());
      SOPln("Venue Name: " + events[counter].getVenueName());
      SOPln("Address: " + events[counter].getAddress());
      System.out.printf("Ticket Price: $%.2f\n", events[counter].getTicketPrice());
      SOPln("Tickets Available: " + events[counter].getAvailableTickets());
      SOPln("-----------------------------------------");
      event+=1;
      counter+=1;
    }
  }
  //viewAllConcessions Method
  public static void viewAllConcessions(Event[] events){
    int event = 1;
    int counter = 0;
    while(event <= events.length){
      SOPln("All Concessions:\n");
      SOPln("-----------------" + events[counter].getEventName() + "-----------------");
      System.out.printf("Popcorn: $%.2f\n", events[counter].getConcessionStand().getPopcornPrice());
      System.out.printf("Soda: $%.2f\n",  events[counter].getConcessionStand().getSodaPrice());
      System.out.printf("Hot Dog: $%.2f\n", events[counter].getConcessionStand().getHotdogPrice());
      event+=1;
      counter+=1;
    }
    }
  //SOP and SOPln Methods
    public static void SOPln(String print){
      System.out.println(print);
      }
    public static void SOP(String print){
      System.out.print(print);
      }
}
